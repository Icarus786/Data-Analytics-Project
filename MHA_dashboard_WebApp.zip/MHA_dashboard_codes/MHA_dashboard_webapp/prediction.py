import pandas as pd
import json
from datetime import datetime

def calculate_proportions(dataframe, column):
    proportions = dataframe[column].value_counts(normalize=True)
    return proportions.to_dict()

def predict_single_month(dataframe):
    # Generate the prediction for the current month and year
    current_date = datetime.now()
    month_year = current_date.strftime('%B_%Y')
    
    prediction = {
        month_year: {
            "DIVISION": calculate_proportions(dataframe, 'DIVISION'),
            "PREMISES_TYPE": calculate_proportions(dataframe, 'PREMISES_TYPE'),
            "APPREHENSION_TYPE": calculate_proportions(dataframe, 'APPREHENSION_TYPE'),
            "SEX": calculate_proportions(dataframe, 'SEX'),
            "AGE_COHORT": calculate_proportions(dataframe, 'AGE_COHORT'),
            "NEIGHBOURHOOD_158": calculate_proportions(dataframe, 'Neighbourhood_158'),
            "Apprehension_Type_Recoded": calculate_proportions(dataframe, 'Apprehension_Type_Recoded'),
            "Division_Recoded": calculate_proportions(dataframe, 'Division_Recoded')
        }
    }
    
    # Convert keys of inner dictionaries to strings
    for key in prediction[month_year]:
        if isinstance(prediction[month_year][key], dict):
            prediction[month_year][key] = {str(k): v for k, v in prediction[month_year][key].items()}
    return prediction
#     return json.dumps(prediction, indent=4)

# # Load the dataset
# file_path = '/content/mha_dataset.csv'
# df = pd.read_csv(file_path)

# # Generate the prediction for the current month
# prediction_json = predict_single_month(df)
# print(prediction_json)