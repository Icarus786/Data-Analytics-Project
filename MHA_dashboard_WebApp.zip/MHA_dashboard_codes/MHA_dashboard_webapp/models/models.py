from db_config import db 

class Division(db.Model):
    id = db.Column(db.String(10), primary_key=True)
    name = db.Column(db.String(100))
    events = db.relationship('Event', backref='division', lazy=True)
    predictive_divisions = db.relationship('PredictiveDivision', backref='division', lazy=True)

class PremisesType(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.String(100), unique=True, nullable=False)
    events = db.relationship('Event', backref='premises_type', lazy=True)
    predictive_premises_types = db.relationship('PredictivePremisesType', backref='premises_type', lazy=True)

class ApprehensionType(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.String(100), unique=True, nullable=False)
    type_recoded = db.Column(db.String(100), unique=False, nullable=True)
    events = db.relationship('Event', backref='apprehension_type', lazy=True)
    predictive_apprehension_types = db.relationship('PredictiveApprehensionType', backref='apprehension_type', lazy=True)

class Neighbourhood(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    events = db.relationship('Event', backref='neighbourhood', lazy=True)
    predictive_neighbourhoods = db.relationship('PredictiveNeighbourhood', backref='neighbourhood', lazy=True)

class Event(db.Model):
    id = db.Column(db.String(20), primary_key=True)
    report_date = db.Column(db.Date)
    report_year = db.Column(db.Integer)
    report_month = db.Column(db.String(20))
    report_day_of_week = db.Column(db.String(20))
    report_day = db.Column(db.Integer)
    report_hour = db.Column(db.Integer)
    occurence_date = db.Column(db.Date)
    occurence_year = db.Column(db.Integer)
    occurence_month = db.Column(db.String(20))
    occurence_day = db.Column(db.Integer)
    occurence_day_of_week = db.Column(db.String(20))
    occurence_hour = db.Column(db.Integer)
    division_id = db.Column(db.String(10), db.ForeignKey('division.id'), nullable=False)
    premises_type_id = db.Column(db.Integer, db.ForeignKey('premises_type.id'), nullable=False)
    apprehension_type_id = db.Column(db.Integer, db.ForeignKey('apprehension_type.id'), nullable=False)
    sex = db.Column(db.String(10))
    age_cohort = db.Column(db.String(20))
    neighbourhood_id = db.Column(db.Integer, db.ForeignKey('neighbourhood.id'), nullable=False)
    report_date_combined = db.Column(db.Date)
    apprehension_type_recoded = db.Column(db.String(100))
    division_recoded = db.Column(db.String(100))

