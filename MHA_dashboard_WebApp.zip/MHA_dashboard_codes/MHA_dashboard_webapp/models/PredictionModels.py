from .models import *
from datetime import datetime

from db_config import db 


class PredictiveDivision(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    division_id = db.Column(db.String(10), db.ForeignKey('division.id'), nullable=False)
    month = db.Column(db.Integer, nullable=False)
    year = db.Column(db.Integer, nullable=False)
    predicted_value = db.Column(db.Float, nullable=False)

class PredictivePremisesType(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    premises_type_id = db.Column(db.Integer, db.ForeignKey('premises_type.id'), nullable=False)
    month = db.Column(db.Integer, nullable=False)
    year = db.Column(db.Integer, nullable=False)
    predicted_value = db.Column(db.Float, nullable=False)

class PredictiveApprehensionType(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    apprehension_type_id = db.Column(db.Integer, db.ForeignKey('apprehension_type.id'), nullable=False)
    month = db.Column(db.Integer, nullable=False)
    year = db.Column(db.Integer, nullable=False)
    predicted_value = db.Column(db.Float, nullable=False)

class PredictiveNeighbourhood(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    neighbourhood_id = db.Column(db.Integer, db.ForeignKey('neighbourhood.id'), nullable=False)
    month = db.Column(db.Integer, nullable=False)
    year = db.Column(db.Integer, nullable=False)
    predicted_value = db.Column(db.Float, nullable=False)

class PredictiveGender(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sex = db.Column(db.String(10), nullable=False)
    month = db.Column(db.Integer, nullable=False)
    year = db.Column(db.Integer, nullable=False)
    predicted_value = db.Column(db.Float, nullable=False)
    
    
def save_predictive_data(data):
    for date_str, values in data.items():
        date = datetime.strptime(date_str, "%B_%Y")
        month, year = date.month, date.year

        # Save PredictiveDivision
        for division_id, score in values['DIVISION'].items():
            division = Division.query.filter_by(id=division_id).first()
            if division:
                pred_division = PredictiveDivision(division_id=division.id, month=month, year=year, predicted_value=score)
                db.session.add(pred_division)

        # Save PredictivePremisesType
        for premises_type_name, score in values['PREMISES_TYPE'].items():
            premises_type = PremisesType.query.filter_by(type=premises_type_name).first()
            if premises_type:
                pred_premises = PredictivePremisesType(premises_type_id=premises_type.id, month=month, year=year, predicted_value=score)
                db.session.add(pred_premises)

        # Save PredictiveApprehensionType
        for apprehension_type_name, score in values['APPREHENSION_TYPE'].items():
            app_type = ApprehensionType.query.filter_by(type=apprehension_type_name).first()
            if app_type:
                pred_app_type = PredictiveApprehensionType(apprehension_type_id=app_type.id, month=month, year=year, predicted_value=score)
                db.session.add(pred_app_type)

        # Save PredictiveNeighbourhood
        for neighbourhood_id, score in values['NEIGHBOURHOOD_158'].items():
            neighbourhood = Neighbourhood.query.filter_by(id=neighbourhood_id).first()
            if neighbourhood:
                pred_neighbourhood = PredictiveNeighbourhood(neighbourhood_id=neighbourhood.id, month=month, year=year, predicted_value=score)
                db.session.add(pred_neighbourhood)

        # Save PredictiveGender
        for gender, score in values['SEX'].items():
            pred_gender = PredictiveGender(sex=gender, month=month, year=year, predicted_value=score)
            db.session.add(pred_gender)

        # # Save PredictiveAgeCohort
        # for age_cohort, score in values['AGE_COHORT'].items():
        #     pred_age_cohort = PredictiveAgeCohort(age_cohort=age_cohort, month=month, year=year, predicted_value=score)
        #     db.session.add(pred_age_cohort)

        # # Save PredictiveApprehensionTypeRecoded
        # for apprehension_type_recoded, score in values['Apprehension_Type_Recoded'].items():
        #     pred_app_type_recoded = PredictiveApprehensionTypeRecoded(apprehension_type=apprehension_type_recoded, month=month, year=year, predicted_value=score)
        #     db.session.add(pred_app_type_recoded)

        # # Save PredictiveDivisionRecoded
        # for division_recoded, score in values['Division_Recoded'].items():
        #     pred_div_recoded = PredictiveDivisionRecoded(division_name=division_recoded, month=month, year=year, predicted_value=score)
        #     db.session.add(pred_div_recoded)

    db.session.commit()