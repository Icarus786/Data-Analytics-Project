import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from sklearn.ensemble import RandomForestClassifier                                                                                     # type: ignore
from sklearn.model_selection import train_test_split                                                                                    # type: ignore
from sklearn.preprocessing import LabelEncoder                                                                                          # type: ignore

def engineer_features(df):
    df['day_of_week'] = pd.to_datetime(df['REPORT_DATE']).dt.dayofweek
    df['month'] = pd.to_datetime(df['REPORT_DATE']).dt.month
    df['year'] = pd.to_datetime(df['REPORT_DATE']).dt.year
    return df

def train_model(df, target_column):
    X = df[['day_of_week', 'month', 'year']]
    y = df[target_column]
    
    le = LabelEncoder()
    y = le.fit_transform(y)
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    return model, le

def predict_proportions(model, le, future_date):
    future_features = np.array([[future_date.dayofweek, future_date.month, future_date.year]])
    predictions = model.predict_proba(future_features)[0]
    class_names = le.classes_
    return dict(zip(class_names, predictions))

def predict_single_month(dataframe):
    dataframe = engineer_features(dataframe)
    current_date = datetime.now()
    future_date = current_date + timedelta(days=30)  # Predict for next month
    month_year = future_date.strftime('%B_%Y')
    
    prediction = {month_year: {}}
    
    for column in ['DIVISION', 'PREMISES_TYPE', 'APPREHENSION_TYPE', 'SEX', 'AGE_COHORT', 'Neighbourhood_158', 'Apprehension_Type_Recoded', 'Division_Recoded']:
        model, le = train_model(dataframe, column)
        prediction[month_year][column] = predict_proportions(model, le, future_date)
    
    # Convert all values to strings for consistency
    for key in prediction[month_year]:
        prediction[month_year][key] = {str(k): float(v) for k, v in prediction[month_year][key].items()}
    
    return prediction
