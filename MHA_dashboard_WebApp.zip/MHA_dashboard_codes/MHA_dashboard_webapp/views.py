import csv
import json
from flask import Blueprint, request, render_template, redirect, url_for, flash
from models import db, Division, PremisesType, ApprehensionType, Neighbourhood, Event
from models import *
from sqlalchemy.exc import IntegrityError
from datetime import datetime
from utils import get_or_create, parse_date


views = Blueprint('views', __name__)

@views.route('/')
def index():
    return render_template('index.html')



@views.route('/upload_csv', methods=['GET', 'POST'])
def upload_csv():
    if request.method == 'POST':
        file = request.files['file']
        if not file:
            flash('No file selected', 'error')
            return redirect(request.url)

        file_content = file.stream.read().decode("utf-8")
        csv_reader = csv.DictReader(file_content.splitlines())

        for row in csv_reader:
            try:
                division, _ = get_or_create(db.session, Division, id=row['DIVISION'], name=row['Division_Recoded'])
                premises_type, _ = get_or_create(db.session, PremisesType, type=row['PREMISES_TYPE'])
                apprehension_type, _ = get_or_create(db.session, ApprehensionType, type=row['APPREHENSION_TYPE'])
                neighbourhood, _ = get_or_create(db.session, Neighbourhood, name=row['NEIGHBOURHOOD_158'])

                event, created = get_or_create(
                    db.session,
                    Event,
                    id=row['EVENT_UNIQUE_ID'],
                    report_date=parse_date(row['REPORT_DATE']),
                    report_year=int(row['REPORT_YEAR']),
                    report_month=row['REPORT_MONTH'],
                    report_day_of_week=row['Report_Day_of_Week'],
                    report_day=int(row['REPORT_DAY']),
                    report_hour=int(row['REPORT_HOUR']),
                    occurence_date=parse_date(row['Occurence_Date']),
                    occurence_year=int(row['Occurence_Year']),
                    occurence_month=row['Occurence_Month'],
                    occurence_day=int(row['Occurence_Day']),
                    occurence_day_of_week=row['Occurence_Day_of_Week'],
                    occurence_hour=int(row['Occurence_Hour']),
                    division_id=division.id,
                    premises_type_id=premises_type.id,
                    apprehension_type_id=apprehension_type.id,
                    sex=row['SEX'],
                    age_cohort=row['AGE_COHORT'],
                    neighbourhood_id=neighbourhood.id,
                    report_date_combined=parse_date(row['REPORT_DATE_COMBINED']),
                    apprehension_type_recoded=row['Apprehension_Type_Recoded'],
                    division_recoded=row['Division_Recoded']
                )
                db.session.add(event)
                db.session.commit()

            except IntegrityError:
                db.session.rollback()
                flash(f"Error processing row with EVENT_UNIQUE_ID {row['EVENT_UNIQUE_ID']}", 'error')

        flash('CSV file processed successfully', 'success')
        return redirect(url_for('views.index'))

    return render_template('upload.html')


# @views.route('/upload_csv', methods=['GET', 'POST'])
# def upload_csv():
#     if request.method == 'POST':
#         file = request.files['file']
#         if not file:
#             flash('No file selected', 'error')
#             return redirect(request.url)

#         file_content = file.stream.read().decode("utf-8")
#         csv_reader = csv.DictReader(file_content.splitlines())

#         for row in csv_reader:
#             try:
#                 # Fetch the apprehension type object
#                 apprehension_type = db.session.query(ApprehensionType).filter_by(type=row['APPREHENSION_TYPE']).first()
                
#                 if apprehension_type:
#                     # Update the type_recoded value
#                     apprehension_type.type_recoded = row['Apprehension_Type_Recoded']
#                     db.session.commit()
#                 else:
#                     flash(f"Apprehension type {row['APPREHENSION_TYPE']} not found", 'error')

#             except IntegrityError:
#                 db.session.rollback()
#                 flash(f"Error processing row with APPREHENSION_TYPE {row['APPREHENSION_TYPE']}", 'error')

#         flash('CSV file processed successfully', 'success')
#         return redirect(url_for('views.index'))

#     return render_template('upload.html')


@views.route('/create_sample_data')
def create_sample_data():
    # Create a division
    division = Division(id='D42', name='242 Milner Av E')
    db.session.add(division)
    db.session.commit()

    # Create a premises type
    premises_type = PremisesType(type='House')
    db.session.add(premises_type)
    db.session.commit()

    # Create an apprehension type
    apprehension_type = ApprehensionType(type='Mha Sec 17 (Power Of App)')
    db.session.add(apprehension_type)
    db.session.commit()

    # Create a neighbourhood
    neighbourhood = Neighbourhood(name='Morningside Heights')
    db.session.add(neighbourhood)
    db.session.commit()

    # Create an event
    event = Event(
        id='GO-20141263946',
        report_date=datetime.strptime('2014-01-01', '%Y-%m-%d').date(),
        report_year=2014,
        report_month='January',
        report_day_of_week='Wednesday',
        report_day=1,
        report_hour=19,
        occurence_date=datetime.strptime('2014-01-01', '%Y-%m-%d').date(),
        occurence_year=2014,
        occurence_month='January',
        occurence_day=1,
        occurence_day_of_week='Wednesday',
        occurence_hour=19,
        division_id=division.id,
        premises_type_id=premises_type.id,
        apprehension_type_id=apprehension_type.id,
        sex='Male',
        age_cohort='55-64',
        neighbourhood_id=neighbourhood.id,
        report_date_combined=datetime.strptime('2014-01-01', '%Y-%m-%d').date(),
        apprehension_type_recoded="Police Officer's Power of Apprehension",
        division_recoded='242 Milner Av E'
    )
    db.session.add(event)
    db.session.commit()

    return 'Sample data created!'

@views.route('/query_data')
def query_data():
    # Query all events
    events = Event.query.all()
    
    # Query events for a specific division
    division_events = Event.query.filter_by(division_id='D42').all()
    
    # Query events for a specific premises type
    premises_events = Event.query.join(PremisesType).filter(PremisesType.type == 'House').all()
    
    # Query events for a specific apprehension type
    apprehension_events = Event.query.join(ApprehensionType).filter(ApprehensionType.type == 'Mha Sec 17 (Power Of App)').all()
    
    # Query events for a specific neighbourhood
    neighbourhood_events = Event.query.join(Neighbourhood).filter(Neighbourhood.name == 'Morningside Heights').all()
    print("EVENTS", events)
    event = events[0]
    print("EVENT", event.id)
    return f'''
        All Events: {list(events)}<br>
        Division Events: {division_events}<br>
        Premises Events: {premises_events}<br>
        Apprehension Events: {apprehension_events}<br>
        Neighbourhood Events: {neighbourhood_events}
    '''

@views.route('/upload_predictive_data')
def save_predictive_data():
    with open('models/data.json', 'r') as file:
        data = json.load(file)
    for date_str, values in data.items():
        date = datetime.strptime(date_str, "%B_%Y")
        month, year = date.month, date.year

        # Save PredictiveDivision
        for division_id, score in values['DIVISION'].items():
            division = Division.query.filter_by(id=division_id).first()
            if division:
                pred_division = PredictiveDivision(division_id=division.id, month=month, year=year, predicted_value=score)
                db.session.add(pred_division)

        # Save PredictivePremisesType
        for premises_type_name, score in values['PREMISES_TYPE'].items():
            premises_type = PremisesType.query.filter_by(type=premises_type_name).first()
            if premises_type:
                pred_premises = PredictivePremisesType(premises_type_id=premises_type.id, month=month, year=year, predicted_value=score)
                db.session.add(pred_premises)

        # Save PredictiveApprehensionType
        for apprehension_type_name, score in values['APPREHENSION_TYPE'].items():
            app_type = ApprehensionType.query.filter_by(type=apprehension_type_name).first()
            if app_type:
                pred_app_type = PredictiveApprehensionType(apprehension_type_id=app_type.id, month=month, year=year, predicted_value=score)
                db.session.add(pred_app_type)

        # Save PredictiveNeighbourhood
        for neighbourhood_id, score in values['NEIGHBOURHOOD_158'].items():
            neighbourhood = Neighbourhood.query.filter_by(id=neighbourhood_id).first()
            if neighbourhood:
                pred_neighbourhood = PredictiveNeighbourhood(neighbourhood_id=neighbourhood.id, month=month, year=year, predicted_value=score)
                db.session.add(pred_neighbourhood)

        # Save PredictiveGender
        for gender, score in values['SEX'].items():
            pred_gender = PredictiveGender(sex=gender, month=month, year=year, predicted_value=score)
            db.session.add(pred_gender)
    db.session.commit()
    return "Predictive Data Uploaded Sugessfully"