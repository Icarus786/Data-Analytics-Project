from flask import Flask
from db_config import db
from views import views
from graphs import graphs 


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///mental_health.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

app.secret_key = 'geOrgI@nC0ll2g3'  

db.init_app(app)
app.register_blueprint(views)
app.register_blueprint(graphs)

    
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
