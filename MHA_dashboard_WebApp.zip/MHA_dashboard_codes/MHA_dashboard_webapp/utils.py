from sqlalchemy.exc import IntegrityError
from datetime import datetime


def get_or_create(session, model, **kwargs):
    instance = session.query(model).filter_by(**kwargs).first()
    if instance:
        return instance, False
    else:
        instance = model(**kwargs)
        session.add(instance)
        session.commit()
        return instance, True

def parse_date(date_str):
    for fmt in ('%Y-%m-%d', '%d-%b-%y'):
        try:
            return datetime.strptime(date_str, fmt).date()
        except ValueError:
            continue
    raise ValueError(f"time data '{date_str}' does not match any known formats")
