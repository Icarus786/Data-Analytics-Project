<script>
    // Utility function to get random colors
    function getRandomColor() {
        const letters = '0123456789ABCDEF';
        let color = '#';
        for (let i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }

    // Events by Year Chart
    fetch('/api/events_by_year')
        .then(response => response.json())
        .then(data => {
            const ctx = document.getElementById('eventsByYearChart').getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.map(item => item.year),
                    datasets: [{
                        label: 'Number of Events',
                        data: data.map(item => item.count),
                        borderColor: 'rgb(75, 192, 192)',
                        tension: 0.1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        title: {
                            display: true,
                            text: 'Events by Year'
                        }
                    }
                }
            });
        });

    // Events by Division Chart
    fetch('/api/events_by_division')
        .then(response => response.json())
        .then(data => {
            const ctx = document.getElementById('eventsByDivisionChart').getContext('2d');
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: data.map(item => item.division),
                    datasets: [{
                        label: 'Number of Events',
                        data: data.map(item => item.count),
                        backgroundColor: data.map(() => getRandomColor())
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        title: {
                            display: true,
                            text: 'Events by Division'
                        }
                    }
                }
            });
        });

    // Events by Premises Type Chart
    fetch('/api/events_by_premises_type')
        .then(response => response.json())
        .then(data => {
            const ctx = document.getElementById('eventsByPremisesTypeChart').getContext('2d');
            new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: data.map(item => item.type),
                    datasets: [{
                        data: data.map(item => item.count),
                        backgroundColor: data.map(() => getRandomColor())
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        title: {
                            display: true,
                            text: 'Events by Premises Type'
                        }
                    }
                }
            });
        });

    // Events by Age Cohort Chart
    fetch('/api/events_by_age_cohort')
        .then(response => response.json())
        .then(data => {
            const ctx = document.getElementById('eventsByAgeCohortChart').getContext('2d');
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: data.map(item => item.age_cohort),
                    datasets: [{
                        data: data.map(item => item.count),
                        backgroundColor: data.map(() => getRandomColor())
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        title: {
                            display: true,
                            text: 'Events by Age Cohort'
                        }
                    }
                }
            });
        });

    // Events by Month and Year Chart
    fetch('/api/events_by_month_and_year')
        .then(response => response.json())
        .then(data => {
            const years = [...new Set(data.map(item => item.year))];
            const datasets = years.map(year => ({
                label: year.toString(),
                data: data.filter(item => item.year === year).map(item => item.count),
                borderColor: getRandomColor(),
                fill: false
            }));

            const ctx = document.getElementById('eventsByMonthYearChart').getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                    datasets: datasets
                },
                options: {
                    responsive: true,
                    plugins: {
                        title: {
                            display: true,
                            text: 'Events by Month and Year'
                        }
                    }
                }
            });
        });
</script>