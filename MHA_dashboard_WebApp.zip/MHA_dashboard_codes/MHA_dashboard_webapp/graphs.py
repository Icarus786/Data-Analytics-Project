from flask import Blueprint, jsonify, render_template
from models import Event, Neighbourhood, db, PremisesType, Division, ApprehensionType
from models import PredictiveDivision, PredictivePremisesType, PredictiveApprehensionType, PredictiveNeighbourhood, PredictiveGender
from sqlalchemy import func
from flask import request, jsonify


graphs = Blueprint('graphs', __name__)

@graphs.route('/graphs/filters_data')
def filters_data():
    divisions = [d.name for d in Division.query.all()]
    premises_types = [p.type for p in PremisesType.query.all()]
    apprehension_types = [a.type for a in ApprehensionType.query.all()]
    neighbourhoods = [n.name for n in Neighbourhood.query.all()]
    sexes = ['Male', 'Female', 'Other']
    
    return jsonify({
        'divisions': divisions,
        'premisesTypes': premises_types,
        'apprehensionTypes': apprehension_types,
        'neighbourhoods': neighbourhoods,
        'sexes': sexes
    })
    
@graphs.route('/graphs/get_filter_options')
def get_filter_options():
    divisions = db.session.query(Division.id, Division.name).distinct().all()
    premises_types = db.session.query(PremisesType.id, PremisesType.type).distinct().all()
    apprehension_types = db.session.query(ApprehensionType.id, ApprehensionType.type).distinct().all()
    neighbourhoods = db.session.query(Neighbourhood.id, Neighbourhood.name).distinct().all()
    sexes = ['Male', 'Female', 'Other']

    return jsonify({
        'divisions': [{'value': d.id, 'label': d.name} for d in divisions],
        'apprehension_types': [{'value': a.id, 'label': a.type} for a in apprehension_types],
        'neighbourhoods': [{'value': n.id, 'label': n.name} for n in neighbourhoods],
        'premises_types': [{'value': p.id, 'label': p.type} for p in premises_types],
        'sexes': [{'value': s, 'label': s} for s in sexes]
    })


@graphs.route('/')
def index():
    return render_template('graph_index.html')

@graphs.route('/graphs/report_by_year')
def report_by_year():
    return render_template('report_by_year.html')

@graphs.route('/graphs/report_by_year_data')
def report_by_year_data():
    division_ids = request.args.get('division_id', '').split(',')
    premises_type_ids = request.args.get('premises_type_id', '').split(',')
    apprehension_type_ids = request.args.get('apprehension_type_id', '').split(',')
    sexes = request.args.get('sex', '').split(',')

    division_ids = [id for id in division_ids if id]
    premises_type_ids = [id for id in premises_type_ids if id]
    apprehension_type_ids = [id for id in apprehension_type_ids if id]
    sexes = [sex for sex in sexes if sex]

    query = db.session.query(Event.report_year, func.count(Event.id)).group_by(Event.report_year)

    if division_ids:
        query = query.filter(Event.division_id.in_(division_ids))
    if premises_type_ids:
        print(premises_type_ids)
        query = query.filter(Event.premises_type_id.in_(premises_type_ids))
    if apprehension_type_ids:
        query = query.filter(Event.apprehension_type_id.in_(apprehension_type_ids))
    if sexes:
        query = query.filter(Event.sex.in_(sexes))

    data = query.all()
    result = {'labels': [str(row[0]) for row in data], 'values': [row[1] for row in data]}
    return jsonify(result)

@graphs.route('/graphs/report_by_month')
def report_by_month():
    return render_template('report_by_month.html')

@graphs.route('/graphs/report_by_month_data')
def report_by_month_data():
    division_ids = request.args.getlist('division_id')
    premises_type_ids = request.args.getlist('premises_type_id')
    apprehension_type_ids = request.args.getlist('apprehension_type_id')
    sexes = request.args.getlist('sex')

    query = db.session.query(Event.report_month, func.count(Event.id)).group_by(Event.report_month)

    if division_ids:
        query = query.filter(Event.division_id.in_(division_ids))
    if premises_type_ids:
        query = query.filter(Event.premises_type_id.in_(premises_type_ids))
    if apprehension_type_ids:
        query = query.filter(Event.apprehension_type_id.in_(apprehension_type_ids))
    if sexes:
        query = query.filter(Event.sex.in_(sexes))

    data = query.all()
    result = {'labels': [row[0] for row in data], 'values': [row[1] for row in data]}
    return jsonify(result)

@graphs.route('/graphs/sex_distribution')
def sex_distribution():
    return render_template('sex_distribution.html')

@graphs.route('/graphs/sex_distribution_data')
def sex_distribution_data():
    division_ids = request.args.getlist('division_id')
    premises_type_ids = request.args.getlist('premises_type_id')
    apprehension_type_ids = request.args.getlist('apprehension_type_id')

    query = db.session.query(Event.sex, func.count(Event.id)).group_by(Event.sex)

    if division_ids:
        query = query.filter(Event.division_id.in_(division_ids))
    if premises_type_ids:
        query = query.filter(Event.premises_type_id.in_(premises_type_ids))
    if apprehension_type_ids:
        query = query.filter(Event.apprehension_type_id.in_(apprehension_type_ids))

    data = query.all()
    result = {'labels': [row[0] for row in data], 'values': [row[1] for row in data]}
    return jsonify(result)

@graphs.route('/graphs/age_cohort_distribution')
def age_cohort_distribution():
    return render_template('age_cohort_distribution.html')

@graphs.route('/graphs/age_cohort_distribution_data')
def age_cohort_distribution_data():
    division_ids = request.args.getlist('division_id')
    premises_type_ids = request.args.getlist('premises_type_id')
    apprehension_type_ids = request.args.getlist('apprehension_type_id')
    sexes = request.args.getlist('sex')

    query = db.session.query(Event.age_cohort, func.count(Event.id)).group_by(Event.age_cohort)

    if division_ids:
        query = query.filter(Event.division_id.in_(division_ids))
    if premises_type_ids:
        query = query.filter(Event.premises_type_id.in_(premises_type_ids))
    if apprehension_type_ids:
        query = query.filter(Event.apprehension_type_id.in_(apprehension_type_ids))
    if sexes:
        query = query.filter(Event.sex.in_(sexes))

    data = query.all()
    result = {'labels': [row[0] for row in data], 'values': [row[1] for row in data]}
    return jsonify(result)

@graphs.route('/graphs/correlation_month_sex')
def correlation_month_sex():
    return render_template('correlation_month_sex.html')

@graphs.route('/graphs/correlation_month_sex_data')
def correlation_month_sex_data():
    division_ids = request.args.getlist('division_id')
    premises_type_ids = request.args.getlist('premises_type_id')
    apprehension_type_ids = request.args.getlist('apprehension_type_id')
    sexes = request.args.getlist('sex')

    query = db.session.query(
        Event.report_month,
        Event.sex,
        func.count(Event.id)
    ).group_by(Event.report_month, Event.sex).order_by(Event.report_month)

    if division_ids:
        query = query.filter(Event.division_id.in_(division_ids))
    if premises_type_ids:
        query = query.filter(Event.premises_type_id.in_(premises_type_ids))
    if apprehension_type_ids:
        query = query.filter(Event.apprehension_type_id.in_(apprehension_type_ids))
    if sexes:
        query = query.filter(Event.sex.in_(sexes))

    data = query.all()
    result = {'months': list(set(row[0] for row in data)), 'data': {}}

    for month, sex, count in data:
        if month not in result['data']:
            result['data'][month] = {'Male': 0, 'Female': 0}
        result['data'][month][sex] = count

    return jsonify(result)

@graphs.route('/graphs/correlation_age_neighbourhood')
def correlation_age_neighbourhood():
    return render_template('correlation_age_neighbourhood.html')


@graphs.route('/graphs/predictive_division')
def predictive_division():
    return render_template('predictive_division.html')

@graphs.route('/graphs/predictive_division_data')
def predictive_division_data():
    data = db.session.query(
        Division.name,
        func.avg(PredictiveDivision.predicted_value),
        PredictiveDivision.month,
        PredictiveDivision.year
    ).join(Division, PredictiveDivision.division_id == Division.id).group_by(
        Division.name,
        PredictiveDivision.month,
        PredictiveDivision.year
    ).all()

    result = {
        'labels': [row[0] for row in data],
        'values': [float(row[1])*100 for row in data],
        'month': data[0][2] if data else None,
        'year': data[0][3] if data else None
    }
    return jsonify(result)

@graphs.route('/graphs/predictive_premises_type')
def predictive_premises_type():
    return render_template('predictive_premises_type.html')

@graphs.route('/graphs/predictive_premises_type_data')
def predictive_premises_type_data():
    data = db.session.query(
        PremisesType.type,
        func.avg(PredictivePremisesType.predicted_value),
        PredictivePremisesType.month,
        PredictivePremisesType.year
    ).join(PremisesType, PredictivePremisesType.premises_type_id == PremisesType.id).group_by(
        PremisesType.type,
        PredictivePremisesType.month,
        PredictivePremisesType.year
    ).order_by(func.avg(PredictivePremisesType.predicted_value).desc()).limit(5).all()  
    
    result = {
        'labels': [row[0] for row in data],
        'values': [float(row[1]) for row in data],  
        'month': data[0][2] if data else None,
        'year': data[0][3] if data else None
    }
    return jsonify(result)


@graphs.route('/graphs/predictive_apprehension_type')
def predictive_apprehension_type():
    return render_template('predictive_apprehension_type.html')

@graphs.route('/graphs/predictive_apprehension_type_data')
def predictive_apprehension_type_data():
    data = db.session.query(
        ApprehensionType.type_recoded,
        func.avg(PredictiveApprehensionType.predicted_value),
        PredictiveApprehensionType.month,
        PredictiveApprehensionType.year
    ).join(ApprehensionType, PredictiveApprehensionType.apprehension_type_id == ApprehensionType.id).group_by(
        ApprehensionType.type_recoded,
        PredictiveApprehensionType.month,
        PredictiveApprehensionType.year
    ).all()
    
    result = {
        'labels': [row[0] for row in data],  
        'values': [float(row[1])*100 for row in data],
        'month': data[0][2] if data else None,
        'year': data[0][3] if data else None
    }
    return jsonify(result)

@graphs.route('/graphs/predictive_neighbourhood')
def predictive_neighbourhood():
    return render_template('predictive_neighbourhood.html')

@graphs.route('/graphs/predictive_neighbourhood_data')
def predictive_neighbourhood_data():
    data = db.session.query(
        Neighbourhood.name,
        func.avg(PredictiveNeighbourhood.predicted_value),
        PredictiveNeighbourhood.month,
        PredictiveNeighbourhood.year
    ).join(Neighbourhood, PredictiveNeighbourhood.neighbourhood_id == Neighbourhood.id).group_by(
        Neighbourhood.name,
        PredictiveNeighbourhood.month,
        PredictiveNeighbourhood.year
    ).all()

    result = {
        'labels': [row[0] for row in data],
        'values': [float(row[1]) for row in data],
        'month': data[0][2] if data else None,
        'year': data[0][3] if data else None
    }
    return jsonify(result)

@graphs.route('/graphs/predictive_gender')
def predictive_gender():
    return render_template('predictive_gender.html')

@graphs.route('/graphs/predictive_gender_data')
def predictive_gender_data():
    data = db.session.query(
        PredictiveGender.sex,
        func.avg(PredictiveGender.predicted_value),
        PredictiveGender.month,
        PredictiveGender.year
    ).group_by(PredictiveGender.sex, PredictiveGender.month, PredictiveGender.year).all()
    
    result = {
        'labels': [row[0] for row in data],
        'values': [float(row[1]) for row in data],
        'month': data[0][2] if data else None,
        'year': data[0][3] if data else None
    }
    return jsonify(result)
