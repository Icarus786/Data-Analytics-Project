from app import app, db
from models import Division, PremisesType, ApprehensionType, Neighbourhood, PredictiveDivision, PredictivePremisesType, PredictiveApprehensionType, PredictiveNeighbourhood, PredictiveGender
from datetime import datetime

def save_predictive_data(data):
    for date_str, values in data.items():
        date = datetime.strptime(date_str, "%B_%Y")
        month, year = date.month, date.year
        print("SAving 111")
        # Save PredictiveDivision
        for division_id, score in values['DIVISION'].items():
            division = Division.query.filter_by(id=division_id).first()
            if division:
                pred_division = PredictiveDivision(division_id=division.id, month=month, year=year, predicted_value=score)
                db.session.add(pred_division)

        # Save PredictivePremisesType
        for premises_type_name, score in values['PREMISES_TYPE'].items():
            premises_type = PremisesType.query.filter_by(type=premises_type_name).first()
            if premises_type:
                pred_premises = PredictivePremisesType(premises_type_id=premises_type.id, month=month, year=year, predicted_value=score)
                db.session.add(pred_premises)

        # Save PredictiveApprehensionType
        for apprehension_type_name, score in values['APPREHENSION_TYPE'].items():
            app_type = ApprehensionType.query.filter_by(type=apprehension_type_name).first()
            if app_type:
                pred_app_type = PredictiveApprehensionType(apprehension_type_id=app_type.id, month=month, year=year, predicted_value=score)
                db.session.add(pred_app_type)

        # Save PredictiveNeighbourhood
        for neighbourhood_id, score in values['NEIGHBOURHOOD_158'].items():
            neighbourhood = Neighbourhood.query.filter_by(id=neighbourhood_id).first()
            if neighbourhood:
                pred_neighbourhood = PredictiveNeighbourhood(neighbourhood_id=neighbourhood.id, month=month, year=year, predicted_value=score)
                db.session.add(pred_neighbourhood)

        # Save PredictiveGender
        for gender, score in values['SEX'].items():
            pred_gender = PredictiveGender(sex=gender, month=month, year=year, predicted_value=score)
            db.session.add(pred_gender)

        # # Save PredictiveAgeCohort
        # for age_cohort, score in values['AGE_COHORT'].items():
        #     pred_age_cohort = PredictiveAgeCohort(age_cohort=age_cohort, month=month, year=year, predicted_value=score)
        #     db.session.add(pred_age_cohort)

        # # Save PredictiveApprehensionTypeRecoded
        # for apprehension_type_recoded, score in values['Apprehension_Type_Recoded'].items():
        #     pred_app_type_recoded = PredictiveApprehensionTypeRecoded(apprehension_type=apprehension_type_recoded, month=month, year=year, predicted_value=score)
        #     db.session.add(pred_app_type_recoded)

        # # Save PredictiveDivisionRecoded
        # for division_recoded, score in values['Division_Recoded'].items():
        #     pred_div_recoded = PredictiveDivisionRecoded(division_name=division_recoded, month=month, year=year, predicted_value=score)
        #     db.session.add(pred_div_recoded)

    db.session.commit()
    

# import json
# with open('models/data.json', 'r') as file:
#     data = json.load(file)
#     res = save_predictive_data(data)
# print(res)


